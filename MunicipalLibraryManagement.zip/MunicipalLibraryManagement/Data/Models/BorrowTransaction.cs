using System.ComponentModel.DataAnnotations;
using MunicipalLibraryManagement.Data.Enums;

namespace MunicipalLibraryManagement.Data.Models;

public class BorrowTransaction
{
    public int Id { get; set; }
    
    [Required]
    public int UserId { get; set; }
    public User? User { get; set; }

    [Required]
    public int BookId { get; set; }
    public Book? Book { get; set; }

    [Required]
    public int CodeId { get; set; }
    public Code? Code { get; set; }

    [Required]
    public DateTime BorrowDate { get; set; } = DateTime.UtcNow;

    public DateTime? DueDate { get; set; }
    
    public DateTime? ReturnDate { get; set; }

    public TransactionStatus Status { get; set; } = TransactionStatus.Borrowed;

    public decimal? FineAmount { get; set; }
}
