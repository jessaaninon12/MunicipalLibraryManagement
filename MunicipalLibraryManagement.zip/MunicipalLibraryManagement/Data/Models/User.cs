using System.ComponentModel.DataAnnotations;
using MunicipalLibraryManagement.Data.Enums;

namespace MunicipalLibraryManagement.Data.Models;

// Represents an authenticated application user with an assigned authorization role.
public class User
{
    public int Id { get; set; }

    [Required]
    [MaxLength(50)]
    public string Username { get; set; } = string.Empty;

    [Required]
    [MaxLength(512)]
    public string PasswordHash { get; set; } = string.Empty;

    public RoleType Role { get; set; } = RoleType.Student;

    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
}
