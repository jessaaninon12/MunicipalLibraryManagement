using System.ComponentModel.DataAnnotations;
using MunicipalLibraryManagement.Data.Enums;

namespace MunicipalLibraryManagement.Data.Models;

public class Code
{
    public int Id { get; set; }

    [Required]
    public int BookId { get; set; } // mainId
    public Book? Book { get; set; }

    [Required]
    public int CopyNumber { get; set; } // copyId

    [Required]
    [MaxLength(100)]
    public string UniqueCode { get; set; } = string.Empty; // CodeId representation

    public BookStatus Status { get; set; } = BookStatus.Available;

    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
}
