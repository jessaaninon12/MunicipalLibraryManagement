using System.ComponentModel.DataAnnotations;

namespace MunicipalLibraryManagement.Data.Models;

// Represents a catalog item that can be tracked in the library inventory.
public class Book
{
    public int Id { get; set; }

    [Required]
    [MaxLength(150)]
    public string Title { get; set; } = string.Empty;

    [Required]
    [MaxLength(120)]
    public string Author { get; set; } = string.Empty;

    public int? AuthorId { get; set; }
    public Author? AuthorEntity { get; set; }

    [Required]
    [MaxLength(20)]
    public string Isbn { get; set; } = string.Empty;

    [Required]
    [MaxLength(80)]
    public string Genre { get; set; } = string.Empty;

    [Required]
    public DateTime PublicationDate { get; set; } = DateTime.UtcNow.Date;

    [MaxLength(120)]
    public string Publisher { get; set; } = string.Empty;

    [MaxLength(2000)]
    public string Description { get; set; } = string.Empty;

    [Range(0, 1000000)]
    public int Quantity { get; set; }

    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
}
