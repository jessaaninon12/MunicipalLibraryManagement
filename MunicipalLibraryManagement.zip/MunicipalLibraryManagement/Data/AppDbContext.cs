using Microsoft.EntityFrameworkCore;
using MunicipalLibraryManagement.Data.Models;

namespace MunicipalLibraryManagement.Data;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<User> Users => Set<User>();
    public DbSet<Book> Books => Set<Book>();
    public DbSet<Author> Authors => Set<Author>();
    public DbSet<BorrowTransaction> BorrowTransactions => Set<BorrowTransaction>();
    public DbSet<Code> Codes => Set<Code>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasIndex(user => user.Username).IsUnique();
        });

        modelBuilder.Entity<Book>(entity =>
        {
            entity.HasIndex(book => book.Isbn).IsUnique();
        });

        modelBuilder.Entity<BorrowTransaction>(entity =>
        {
            entity.HasOne(t => t.User)
                  .WithMany()
                  .HasForeignKey(t => t.UserId);

            entity.HasOne(t => t.Book)
                  .WithMany()
                  .HasForeignKey(t => t.BookId);

            entity.HasOne(t => t.Code)
                  .WithMany()
                  .HasForeignKey(t => t.CodeId);
        });

        modelBuilder.Entity<Code>(entity =>
        {
            entity.HasIndex(q => q.UniqueCode).IsUnique();
            entity.HasOne(q => q.Book)
                  .WithMany()
                  .HasForeignKey(q => q.BookId);
        });
    }
}
