namespace MunicipalLibraryManagement.Data.Enums;

public enum RoleType
{
    Admin,
    Librarian,
    Student
}
