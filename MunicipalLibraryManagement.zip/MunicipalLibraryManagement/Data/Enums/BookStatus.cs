namespace MunicipalLibraryManagement.Data.Enums;

public enum BookStatus
{
    Available,
    Borrowed,
    Lost,
    Damaged
}
