namespace MunicipalLibraryManagement.Data.Enums;

public enum TransactionStatus
{
    Borrowed,
    Returned,
    Overdue
}
