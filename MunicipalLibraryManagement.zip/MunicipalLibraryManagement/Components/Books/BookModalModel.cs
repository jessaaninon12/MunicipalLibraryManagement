using System.ComponentModel.DataAnnotations;
using MunicipalLibraryManagement.Data.Models;

namespace MunicipalLibraryManagement.Components.Books;

// Captures validated form state for add and edit book modal workflows.
public class BookModalModel
{
    public int Id { get; set; }

    [Required]
    [StringLength(150)]
    public string Title { get; set; } = string.Empty;

    [Required]
    [StringLength(120)]
    public string Author { get; set; } = string.Empty;

    public int? AuthorId { get; set; }

    [Required]
    [StringLength(20, MinimumLength = 10)]
    public string Isbn { get; set; } = string.Empty;

    [Required]
    [StringLength(80)]
    public string Genre { get; set; } = string.Empty;

    [Required]
    public DateTime? PublicationDate { get; set; } = DateTime.Today;

    [StringLength(120)]
    public string Publisher { get; set; } = string.Empty;

    [StringLength(2000)]
    public string Description { get; set; } = string.Empty;

    [Range(0, 1000000)]
    public int Quantity { get; set; }

    public static BookModalModel CreateEmpty() => new()
    {
        PublicationDate = DateTime.Today
    };

    public static BookModalModel FromBook(Book book) => new()
    {
        Id = book.Id,
        Title = book.Title,
        Author = book.Author,
        AuthorId = book.AuthorId,
        Isbn = book.Isbn,
        Genre = book.Genre,
        PublicationDate = book.PublicationDate,
        Publisher = book.Publisher,
        Description = book.Description,
        Quantity = book.Quantity
    };

    public BookModalModel Clone() => new()
    {
        Id = Id,
        Title = Title,
        Author = Author,
        AuthorId = AuthorId,
        Isbn = Isbn,
        Genre = Genre,
        PublicationDate = PublicationDate,
        Publisher = Publisher,
        Description = Description,
        Quantity = Quantity
    };
}
