# Running the Project

Follow these steps to get the Municipal Library Management system up and running on your local machine:

## Step 1: Ensure Database is Running
Make sure your MySQL or MariaDB server is active. You can check this via XAMPP Control Panel or your database service manager.

## Step 2: Update the Database
Open your terminal in the project root folder and run:
```bash
dotnet ef database update
```
*This will apply all migrations and create the necessary tables.*

## Step 3: Run the Application
In the same terminal, run:
```bash
dotnet run --launch-profile https
```
*This starts the web server. You can then open the URL provided in the output (usually https://localhost:7013).*

---

### Default Login Credentials:
- **Admin**: `admin` / `Admin123!`
- **Librarian**: `librarian` / `Lib123!`
- **Student**: `student` / `Student123!`
