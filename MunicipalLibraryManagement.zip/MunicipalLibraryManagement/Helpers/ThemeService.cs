using Microsoft.JSInterop;

namespace MunicipalLibraryManagement.Helpers;

// Stores and restores the user's preferred dark or light theme selection.
public class ThemeService(IJSRuntime jsRuntime)
{
    private const string ThemeStorageKey = "municipalLibrary.theme.isDark";

    public bool IsDarkMode { get; private set; } = true;

    public bool IsInitialized { get; private set; }

    public event Action? ThemeChanged;

    public async Task InitializeAsync()
    {
        if (IsInitialized)
        {
            return;
        }

        try
        {
            var storedValue = await jsRuntime.InvokeAsync<string?>("municipalLibrary.storage.get", ThemeStorageKey);
            if (bool.TryParse(storedValue, out var isDarkMode))
            {
                IsDarkMode = isDarkMode;
            }

            IsInitialized = true;
            ThemeChanged?.Invoke();
        }
        catch (Exception ex) when (ex is JSException or InvalidOperationException or JSDisconnectedException)
        {
            // Fallback to default if JS interop fails during initialization
            IsInitialized = false;
        }
    }

    public Task ToggleAsync() => SetDarkModeAsync(!IsDarkMode);

    public async Task SetDarkModeAsync(bool isDarkMode)
    {
        IsDarkMode = isDarkMode;

        try
        {
            await jsRuntime.InvokeVoidAsync("municipalLibrary.storage.set", ThemeStorageKey, IsDarkMode.ToString());
        }
        catch (InvalidOperationException)
        {
            // Browser storage is only available after the interactive circuit is ready.
        }
        catch (JSDisconnectedException)
        {
            // Ignore disconnects during navigation or shutdown.
        }

        ThemeChanged?.Invoke();
    }
}
