namespace MunicipalLibraryManagement.Helpers;

public static class FineHelper
{
    private const decimal FinePerDay = 10.00m; // Example fine amount

    public static decimal CalculateFine(DateTime dueDate, DateTime returnDate)
    {
        if (returnDate <= dueDate) return 0;

        int overdueDays = (int)(returnDate.Date - dueDate.Date).TotalDays;
        return overdueDays * FinePerDay;
    }
}
