namespace MunicipalLibraryManagement.Helpers;

// Marks routable Blazor pages that require authentication or a specific role.
[AttributeUsage(AttributeTargets.Class, Inherited = true, AllowMultiple = false)]
public sealed class RouteGuardAttribute : Attribute
{
    public string? Role { get; set; }
}
