using System.Security.Claims;
using System.Text.Json;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.JSInterop;
using MunicipalLibraryManagement.Data.Models;
using MunicipalLibraryManagement.Services.Interfaces;

namespace MunicipalLibraryManagement.Helpers;

// Persists the signed-in user in browser storage and exposes claims to Blazor components.
public class CustomAuthenticationStateProvider(IJSRuntime jsRuntime, IUserService userService) : AuthenticationStateProvider
{
    private const string AuthStorageKey = "municipalLibrary.auth.session";
    private AuthenticationState _currentState = new(new ClaimsPrincipal(new ClaimsIdentity()));

    public bool IsInitialized { get; private set; }

    public override Task<AuthenticationState> GetAuthenticationStateAsync() => Task.FromResult(_currentState);

    public async Task InitializeAsync()
    {
        if (IsInitialized)
        {
            return;
        }

        try
        {
            var serializedSession = await jsRuntime.InvokeAsync<string?>("municipalLibrary.storage.get", AuthStorageKey);
            if (!string.IsNullOrWhiteSpace(serializedSession))
            {
                var session = JsonSerializer.Deserialize<StoredUserSession>(serializedSession);
                if (session is not null)
                {
                    var user = await userService.GetByIdAsync(session.UserId);
                    if (user is not null)
                    {
                        SetAuthenticatedUser(user);
                    }
                    else
                    {
                        await ClearStorageAsync();
                    }
                }
            }

            IsInitialized = true;
            NotifyAuthenticationStateChanged(Task.FromResult(_currentState));
        }
        catch (Exception ex) when (ex is JSException or InvalidOperationException or JSDisconnectedException)
        {
            IsInitialized = false;
        }
    }

    public async Task SignInAsync(User user)
    {
        var session = new StoredUserSession { UserId = user.Id };
        var serializedSession = JsonSerializer.Serialize(session);

        await jsRuntime.InvokeVoidAsync("municipalLibrary.storage.set", AuthStorageKey, serializedSession);
        SetAuthenticatedUser(user);
        IsInitialized = true;
        NotifyAuthenticationStateChanged(Task.FromResult(_currentState));
    }

    public async Task SignOutAsync()
    {
        await ClearStorageAsync();
        SetAnonymousUser();
        IsInitialized = true;
        NotifyAuthenticationStateChanged(Task.FromResult(_currentState));
    }

    private async Task ClearStorageAsync()
    {
        try
        {
            await jsRuntime.InvokeVoidAsync("municipalLibrary.storage.remove", AuthStorageKey);
        }
        catch (InvalidOperationException)
        {
            // Browser storage is only available after the interactive circuit is ready.
        }
        catch (JSDisconnectedException)
        {
            // Ignore disconnects during navigation or shutdown.
        }
    }

    private void SetAuthenticatedUser(User user)
    {
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new(ClaimTypes.Name, user.Username),
            new(ClaimTypes.Role, user.Role.ToString())
        };

        var identity = new ClaimsIdentity(claims, "CustomAuth");
        _currentState = new AuthenticationState(new ClaimsPrincipal(identity));
    }

    private void SetAnonymousUser()
    {
        _currentState = new AuthenticationState(new ClaimsPrincipal(new ClaimsIdentity()));
    }

    private class StoredUserSession
    {
        public int UserId { get; set; }
    }
}
