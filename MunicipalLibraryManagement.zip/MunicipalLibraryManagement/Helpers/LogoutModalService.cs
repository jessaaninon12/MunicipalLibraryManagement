namespace MunicipalLibraryManagement.Helpers;

// Coordinates opening and closing the global logout confirmation modal from anywhere in the UI.
public class LogoutModalService
{
    public bool IsOpen { get; private set; }

    public event Action? StateChanged;

    public void Open()
    {
        if (IsOpen)
        {
            return;
        }

        IsOpen = true;
        StateChanged?.Invoke();
    }

    public void Close()
    {
        if (!IsOpen)
        {
            return;
        }

        IsOpen = false;
        StateChanged?.Invoke();
    }
}
