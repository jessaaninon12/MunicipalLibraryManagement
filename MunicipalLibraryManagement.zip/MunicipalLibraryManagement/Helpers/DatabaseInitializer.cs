using Microsoft.EntityFrameworkCore;
using MunicipalLibraryManagement.Data;
using MunicipalLibraryManagement.Data.Enums;
using MunicipalLibraryManagement.Data.Models;
using MunicipalLibraryManagement.Services.Interfaces;

using Microsoft.Extensions.Logging;

namespace MunicipalLibraryManagement.Helpers;

// Applies migrations and seeds baseline data so the project can run immediately after setup.
public class DatabaseInitializer(AppDbContext dbContext, IPasswordHasher passwordHasher, ILogger<DatabaseInitializer> logger)
{
    public async Task InitializeAsync()
    {
        try
        {
            logger.LogInformation("Starting database initialization...");
            await dbContext.Database.MigrateAsync();
            logger.LogInformation("Database migration completed.");

            if (!await dbContext.Users.AnyAsync())
            {
                logger.LogInformation("Seeding users...");
                dbContext.Users.AddRange(
                    new User
                    {
                        Username = "admin",
                        PasswordHash = passwordHasher.Hash("Admin123!"),
                        Role = RoleType.Admin,
                        CreatedUtc = DateTime.UtcNow
                    },
                    new User
                    {
                        Username = "librarian",
                        PasswordHash = passwordHasher.Hash("Lib123!"),
                        Role = RoleType.Librarian,
                        CreatedUtc = DateTime.UtcNow
                    },
                    new User
                    {
                        Username = "student",
                        PasswordHash = passwordHasher.Hash("Student123!"),
                        Role = RoleType.Student,
                        CreatedUtc = DateTime.UtcNow
                    });
            }

            if (!await dbContext.Books.AnyAsync())
            {
                logger.LogInformation("Seeding books...");
                dbContext.Books.AddRange(
                    new Book
                    {
                        Title = "The Pragmatic Programmer",
                        Author = "Andrew Hunt",
                        Isbn = "978-0201616224",
                        Genre = "Software Engineering",
                        PublicationDate = new DateTime(1999, 10, 30),
                        Publisher = "Addison-Wesley",
                        Description = "A practical guide to modern software craftsmanship and sustainable engineering habits.",
                        Quantity = 6,
                        CreatedUtc = DateTime.UtcNow
                    },
                    new Book
                    {
                        Title = "Clean Code",
                        Author = "Robert C. Martin",
                        Isbn = "978-0132350884",
                        Genre = "Programming Practices",
                        PublicationDate = new DateTime(2008, 8, 1),
                        Publisher = "Prentice Hall",
                        Description = "A handbook of agile software craftsmanship focused on readable, maintainable code.",
                        Quantity = 4,
                        CreatedUtc = DateTime.UtcNow
                    },
                    new Book
                    {
                        Title = "Domain-Driven Design",
                        Author = "Eric Evans",
                        Isbn = "978-0321125217",
                        Genre = "Architecture",
                        PublicationDate = new DateTime(2003, 8, 30),
                        Publisher = "Addison-Wesley",
                        Description = "A foundational reference for modeling complex business domains in software systems.",
                        Quantity = 3,
                        CreatedUtc = DateTime.UtcNow
                    });
            }

            await dbContext.SaveChangesAsync();

            // Seed Codes if books exist but Codes don't
            if (await dbContext.Books.AnyAsync() && !await dbContext.Codes.AnyAsync())
            {
                logger.LogInformation("Seeding Codes...");
                var books = await dbContext.Books.ToListAsync();
                foreach (var book in books)
                {
                    for (int i = 1; i <= book.Quantity; i++)
                    {
                        dbContext.Codes.Add(new Code
                        {
                            BookId = book.Id,
                            CopyNumber = i,
                            UniqueCode = $"GLM-{book.Id}-{i}-{DateTime.UtcNow.Ticks + i}",
                            Status = BookStatus.Available,
                            CreatedUtc = DateTime.UtcNow
                        });
                    }
                }
                await dbContext.SaveChangesAsync();
            }
            
            logger.LogInformation("Database initialization successful.");
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "An error occurred during database initialization.");
            throw; // Re-throw to ensure the application knows it failed to initialize.
        }
    }
}
