namespace MunicipalLibraryManagement.Helpers;

public static class DateHelper
{
    public static string ToFriendlyDate(DateTime? date)
    {
        return date?.ToString("MMM dd, yyyy") ?? "N/A";
    }

    public static string ToFriendlyDateTime(DateTime? date)
    {
        return date?.ToString("MMM dd, yyyy HH:mm") ?? "N/A";
    }

    public static int CalculateDaysDifference(DateTime start, DateTime end)
    {
        return (int)(end.Date - start.Date).TotalDays;
    }
}
