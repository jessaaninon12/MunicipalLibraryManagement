namespace MunicipalLibraryManagement.Helpers;

public static class CodeHelper
{
    public static string GenerateUniqueCode(int bookId, int copyId)
    {
        // Simple unique code generation logic
        // Format: GLM-BOOKID-COPYID-TIMESTAMP
        return $"GLM-{bookId}-{copyId}-{DateTime.UtcNow.Ticks}";
    }
}
