using MunicipalLibraryManagement.Data.Models;
using MunicipalLibraryManagement.Repositories.Interfaces;
using MunicipalLibraryManagement.Services.Interfaces;

namespace MunicipalLibraryManagement.Services.Implementations;

// Coordinates validation and book inventory business rules.
public class BookService(IBookRepository bookRepository, ICodeService codeService) : IBookService
{
    public async Task<List<Book>> GetAllAsync()
    {
        var books = await bookRepository.GetAllAsync();
        return books.ToList();
    }

    public async Task<Book> CreateAsync(string title, string author, int? authorId, string isbn, DateTime publicationDate, string genre, string? publisher, string? description, int quantity)
    {
        if (await bookRepository.GetByIsbnAsync(isbn) is not null)
        {
            throw new InvalidOperationException("A book with that ISBN already exists.");
        }

        var book = new Book
        {
            Title = title,
            Author = author,
            AuthorId = authorId,
            Isbn = isbn,
            PublicationDate = publicationDate,
            Genre = genre,
            Publisher = publisher ?? string.Empty,
            Description = description ?? string.Empty,
            Quantity = quantity,
            CreatedUtc = DateTime.UtcNow
        };

        await bookRepository.AddAsync(book);

        // Generate Codes for the initial quantity
        for (int i = 1; i <= quantity; i++)
        {
            await codeService.GenerateCodeForBookAsync(book.Id);
        }

        return book;
    }

    public async Task<Book> UpdateAsync(int id, string title, string author, int? authorId, string isbn, DateTime publicationDate, string genre, string? publisher, string? description, int quantity)
    {
        var book = await bookRepository.GetByIdAsync(id)
            ?? throw new InvalidOperationException("The selected book was not found.");

        var existingWithIsbn = await bookRepository.GetByIsbnAsync(isbn);
        if (existingWithIsbn is not null && existingWithIsbn.Id != id)
        {
            throw new InvalidOperationException("Another book with that ISBN already exists.");
        }

        int oldQuantity = book.Quantity;

        book.Title = title;
        book.Author = author;
        book.AuthorId = authorId;
        book.Isbn = isbn;
        book.PublicationDate = publicationDate;
        book.Genre = genre;
        book.Publisher = publisher ?? string.Empty;
        book.Description = description ?? string.Empty;
        book.Quantity = quantity;

        await bookRepository.UpdateAsync(book);

        // If quantity increased, generate new Codes
        if (quantity > oldQuantity)
        {
            for (int i = oldQuantity + 1; i <= quantity; i++)
            {
                await codeService.GenerateCodeForBookAsync(book.Id);
            }
        }

        return book;
    }

    public async Task DeleteAsync(int id)
    {
        await bookRepository.DeleteAsync(id);
    }

    public Task<Book?> GetByIdAsync(int id) => bookRepository.GetByIdAsync(id);

    public async Task<int> GetBookCountAsync()
    {
        var books = await bookRepository.GetAllAsync();
        return books.Count();
    }

    public async Task<int> GetTotalQuantityAsync()
    {
        var books = await bookRepository.GetAllAsync();
        return books.Sum(b => b.Quantity);
    }
}
