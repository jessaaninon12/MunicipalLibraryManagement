using MunicipalLibraryManagement.Data.Models;
using MunicipalLibraryManagement.Data.Enums;
using MunicipalLibraryManagement.Repositories.Interfaces;
using MunicipalLibraryManagement.Services.Interfaces;
using MunicipalLibraryManagement.Helpers;

namespace MunicipalLibraryManagement.Services.Implementations;

public class CodeService(
    ICodeRepository CodeRepository,
    IBookRepository bookRepository) : ICodeService
{
    public async Task<Code> GenerateCodeForBookAsync(int bookId)
    {
        var book = await bookRepository.GetByIdAsync(bookId)
            ?? throw new Exception("Book not found.");

        var existingCopies = await CodeRepository.GetAllByBookIdAsync(bookId);
        int nextCopyId = existingCopies.Count() + 1;

        var Code = new Code
        {
            BookId = bookId,
            CopyNumber = nextCopyId,
            UniqueCode = CodeHelper.GenerateUniqueCode(bookId, nextCopyId),
            Status = BookStatus.Available,
            CreatedUtc = DateTime.UtcNow
        };

        return await CodeRepository.AddAsync(Code);
    }
}
