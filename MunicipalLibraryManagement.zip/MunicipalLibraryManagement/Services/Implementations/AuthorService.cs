using MunicipalLibraryManagement.Data.Models;
using MunicipalLibraryManagement.Repositories.Interfaces;
using MunicipalLibraryManagement.Services.Interfaces;

namespace MunicipalLibraryManagement.Services.Implementations;

public class AuthorService(IAuthorRepository authorRepository) : IAuthorService
{
    public async Task<List<Author>> GetAllAsync()
    {
        var authors = await authorRepository.GetAllAsync();
        return authors.ToList();
    }

    public Task<Author?> GetByIdAsync(int id) => authorRepository.GetByIdAsync(id);

    public async Task<Author> CreateAsync(string name, string? bio)
    {
        var author = new Author
        {
            Name = name,
            Bio = bio ?? string.Empty,
            CreatedUtc = DateTime.UtcNow
        };
        return await authorRepository.AddAsync(author);
    }

    public async Task<Author> UpdateAsync(int id, string name, string? bio)
    {
        var author = await authorRepository.GetByIdAsync(id)
            ?? throw new InvalidOperationException("Author not found.");

        author.Name = name;
        author.Bio = bio ?? string.Empty;

        await authorRepository.UpdateAsync(author);
        return author;
    }

    public Task DeleteAsync(int id) => authorRepository.DeleteAsync(id);
}
