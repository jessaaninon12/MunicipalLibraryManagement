using MunicipalLibraryManagement.Data.Enums;
using MunicipalLibraryManagement.Data.Models;
using MunicipalLibraryManagement.Repositories.Interfaces;
using MunicipalLibraryManagement.Services.Interfaces;

namespace MunicipalLibraryManagement.Services.Implementations;

// Coordinates validation, credential handling, and user business rules.
public class UserService(IUserRepository userRepository, IPasswordHasher passwordHasher) : IUserService
{
    public async Task<User?> AuthenticateAsync(string username, string password)
    {
        var normalizedUsername = NormalizeUsername(username);
        var user = await userRepository.GetByUsernameAsync(normalizedUsername);

        if (user is null)
        {
            return null;
        }

        return passwordHasher.Verify(user.PasswordHash, password) ? user : null;
    }

    public Task<User> RegisterAsync(string username, string password) =>
        CreateAsync(username, password, RoleType.Student);

    public async Task<User> CreateAsync(string username, string password, RoleType role)
    {
        var normalizedUsername = NormalizeUsername(username);
        ValidatePassword(password);

        if (await userRepository.GetByUsernameAsync(normalizedUsername) is not null)
        {
            throw new InvalidOperationException("That username is already in use.");
        }

        var user = new User
        {
            Username = normalizedUsername,
            PasswordHash = passwordHasher.Hash(password),
            Role = role,
            CreatedUtc = DateTime.UtcNow
        };

        await userRepository.AddAsync(user);
        return user;
    }

    public async Task<User> UpdateAsync(int id, string username, string? password, RoleType role)
    {
        var user = await userRepository.GetByIdAsync(id)
            ?? throw new InvalidOperationException("The selected user was not found.");

        var normalizedUsername = NormalizeUsername(username);
        var existingUser = await userRepository.GetByUsernameAsync(normalizedUsername);
        if (existingUser is not null && existingUser.Id != id)
        {
            throw new InvalidOperationException("That username is already in use.");
        }

        if (!string.IsNullOrWhiteSpace(password))
        {
            ValidatePassword(password);
            user.PasswordHash = passwordHasher.Hash(password);
        }

        user.Username = normalizedUsername;
        user.Role = role;

        await userRepository.UpdateAsync(user);
        return user;
    }

    public async Task DeleteAsync(int id)
    {
        var user = await userRepository.GetByIdAsync(id)
            ?? throw new InvalidOperationException("The selected user was not found.");

        if (user.Role == RoleType.Admin)
        {
            var allUsers = await userRepository.GetAllAsync();
            var remainingAdminCount = allUsers.Count(existingUser => existingUser.Role == RoleType.Admin && existingUser.Id != id);
            if (remainingAdminCount == 0)
            {
                throw new InvalidOperationException("At least one Admin must remain in the system.");
            }
        }

        await userRepository.DeleteAsync(id);
    }

    public async Task<List<User>> GetAllAsync()
    {
        var users = await userRepository.GetAllAsync();
        return users.ToList();
    }

    public Task<User?> GetByIdAsync(int id) => userRepository.GetByIdAsync(id);

    public async Task<int> GetUserCountAsync()
    {
        var users = await userRepository.GetAllAsync();
        return users.Count();
    }

    private static string NormalizeUsername(string username) => username.Trim().ToLowerInvariant();

    private static void ValidatePassword(string password)
    {
        if (string.IsNullOrWhiteSpace(password) || password.Length < 6)
        {
            throw new InvalidOperationException("Password must be at least 6 characters long.");
        }
    }
}
