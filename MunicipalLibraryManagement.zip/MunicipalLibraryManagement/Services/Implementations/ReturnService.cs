using MunicipalLibraryManagement.Data.Models;
using MunicipalLibraryManagement.Data.Enums;
using MunicipalLibraryManagement.Repositories.Interfaces;
using MunicipalLibraryManagement.Services.Interfaces;
using MunicipalLibraryManagement.Helpers;

namespace MunicipalLibraryManagement.Services.Implementations;

public class ReturnService(
    IBorrowRepository borrowRepository,
    IReturnRepository returnRepository,
    ICodeRepository CodeRepository,
    IBookRepository bookRepository) : IReturnService
{
    public async Task<BorrowTransaction> ReturnBookAsync(string uniqueCode)
    {
        var Code = await CodeRepository.GetByUniqueCodeAsync(uniqueCode)
            ?? throw new Exception("QR Code not found.");

        var transaction = await borrowRepository.GetActiveTransactionByCodeIdAsync(Code.Id)
            ?? throw new Exception("No active transaction found for this QR Code.");

        if (transaction.Status == TransactionStatus.Returned)
        {
            throw new Exception("This book has already been returned.");
        }

        var book = await bookRepository.GetByIdAsync(transaction.BookId)
            ?? throw new Exception("Book not found.");

        // Update transaction
        transaction.ReturnDate = DateTime.UtcNow;
        transaction.Status = TransactionStatus.Returned;

        // Check overdue status and calculate fine (using helper)
        if (transaction.DueDate.HasValue && transaction.ReturnDate > transaction.DueDate.Value)
        {
            transaction.FineAmount = FineHelper.CalculateFine(transaction.DueDate.Value, transaction.ReturnDate.Value);
        }

        await returnRepository.UpdateTransactionAsync(transaction);

        // Update Book availability
        book.Quantity++;
        await bookRepository.UpdateAsync(book);

        // Update Code status
        Code.Status = BookStatus.Available;
        await CodeRepository.UpdateAsync(Code);

        return transaction;
    }
}
