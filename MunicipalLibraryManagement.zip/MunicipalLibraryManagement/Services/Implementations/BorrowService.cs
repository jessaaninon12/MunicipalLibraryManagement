using MunicipalLibraryManagement.Data.Models;
using MunicipalLibraryManagement.Data.Enums;
using MunicipalLibraryManagement.Repositories.Interfaces;
using MunicipalLibraryManagement.Services.Interfaces;

namespace MunicipalLibraryManagement.Services.Implementations;

public class BorrowService(
    IBookRepository bookRepository,
    IUserRepository userRepository,
    IBorrowRepository borrowRepository,
    ICodeRepository CodeRepository) : IBorrowService
{
    public async Task<BorrowTransaction> BorrowBookAsync(int userId, int bookId)
    {
        var book = await bookRepository.GetByIdAsync(bookId) 
            ?? throw new Exception("Book not found.");

        var user = await userRepository.GetByIdAsync(userId) 
            ?? throw new Exception("User not found.");

        // Check availability
        var availableCodes = await CodeRepository.GetAllByBookIdAsync(bookId);
        var availableCode = availableCodes.FirstOrDefault(q => q.Status == BookStatus.Available)
            ?? throw new Exception("No available copies of this book.");

        // Check user eligibility (example: max 3 books)
        var userTransactions = await borrowRepository.GetAllAsync();
        var activeTransactions = userTransactions.Count(t => t.UserId == userId && t.Status != TransactionStatus.Returned);
        if (activeTransactions >= 3)
        {
            throw new Exception("User has reached the maximum number of borrowed books.");
        }

        // Create transaction
        var transaction = new BorrowTransaction
        {
            UserId = userId,
            BookId = bookId,
            CodeId = availableCode.Id,
            BorrowDate = DateTime.UtcNow,
            DueDate = DateTime.UtcNow.AddDays(14), // 2 weeks default
            Status = TransactionStatus.Borrowed
        };

        await borrowRepository.AddAsync(transaction);

        // Update Book availability
        book.Quantity--;
        await bookRepository.UpdateAsync(book);

        // Update Code status
        availableCode.Status = BookStatus.Borrowed;
        await CodeRepository.UpdateAsync(availableCode);

        return transaction;
    }

    public async Task<IEnumerable<BorrowTransaction>> GetUserTransactionsAsync(int userId)
    {
        return await borrowRepository.GetByUserIdAsync(userId);
    }
}
