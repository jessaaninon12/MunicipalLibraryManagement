using MunicipalLibraryManagement.Data.Enums;
using MunicipalLibraryManagement.Data.Models;

namespace MunicipalLibraryManagement.Services.Interfaces;

// Defines business logic for authentication and user administration.
public interface IUserService
{
    Task<User?> AuthenticateAsync(string username, string password);
    Task<User> RegisterAsync(string username, string password);
    Task<User> CreateAsync(string username, string password, RoleType role);
    Task<User> UpdateAsync(int id, string username, string? password, RoleType role);
    Task DeleteAsync(int id);
    Task<List<User>> GetAllAsync();
    Task<User?> GetByIdAsync(int id);
    Task<int> GetUserCountAsync();
}
