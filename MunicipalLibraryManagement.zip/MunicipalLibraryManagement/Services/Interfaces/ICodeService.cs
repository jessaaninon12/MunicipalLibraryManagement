using MunicipalLibraryManagement.Data.Models;

namespace MunicipalLibraryManagement.Services.Interfaces;

public interface ICodeService
{
    Task<Code> GenerateCodeForBookAsync(int bookId);
}
