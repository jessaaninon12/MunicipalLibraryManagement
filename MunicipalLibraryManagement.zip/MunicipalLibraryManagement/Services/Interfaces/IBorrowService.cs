using MunicipalLibraryManagement.Data.Models;

namespace MunicipalLibraryManagement.Services.Interfaces;

public interface IBorrowService
{
    Task<BorrowTransaction> BorrowBookAsync(int userId, int bookId);
    Task<IEnumerable<BorrowTransaction>> GetUserTransactionsAsync(int userId);
}
