using MunicipalLibraryManagement.Data.Models;

namespace MunicipalLibraryManagement.Services.Interfaces;

public interface IAuthorService
{
    Task<List<Author>> GetAllAsync();
    Task<Author?> GetByIdAsync(int id);
    Task<Author> CreateAsync(string name, string? bio);
    Task<Author> UpdateAsync(int id, string name, string? bio);
    Task DeleteAsync(int id);
}
