namespace MunicipalLibraryManagement.Services.Interfaces;

// Encapsulates password hashing and verification so security logic stays injectable.
public interface IPasswordHasher
{
    string Hash(string password);
    bool Verify(string hash, string password);
}
