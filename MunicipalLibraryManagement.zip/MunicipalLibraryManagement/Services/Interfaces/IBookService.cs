using MunicipalLibraryManagement.Data.Models;

namespace MunicipalLibraryManagement.Services.Interfaces;

// Defines business logic for library book inventory management.
public interface IBookService
{
    Task<List<Book>> GetAllAsync();
    Task<Book> CreateAsync(string title, string author, int? authorId, string isbn, DateTime publicationDate, string genre, string? publisher, string? description, int quantity);
    Task<Book> UpdateAsync(int id, string title, string author, int? authorId, string isbn, DateTime publicationDate, string genre, string? publisher, string? description, int quantity);
    Task DeleteAsync(int id);
    Task<Book?> GetByIdAsync(int id);
    Task<int> GetBookCountAsync();
    Task<int> GetTotalQuantityAsync();
}
