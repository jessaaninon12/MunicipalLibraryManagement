using MunicipalLibraryManagement.Data.Models;

namespace MunicipalLibraryManagement.Services.Interfaces;

public interface IReturnService
{
    Task<BorrowTransaction> ReturnBookAsync(string uniqueCode);
}
