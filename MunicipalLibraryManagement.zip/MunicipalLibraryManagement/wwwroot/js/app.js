// Provides browser storage helpers for theme persistence and user session restoration.
window.municipalLibrary = window.municipalLibrary || {};
window.municipalLibrary.storage = {
    get: function (key) {
        return window.localStorage.getItem(key);
    },
    set: function (key, value) {
        window.localStorage.setItem(key, value);
    },
    remove: function (key) {
        window.localStorage.removeItem(key);
    }
};

window.municipalLibrary.modal = {
    activate: function (element) {
        if (!element) {
            return;
        }

        const focusableSelectors = [
            "button:not([disabled])",
            "[href]",
            "input:not([disabled])",
            "select:not([disabled])",
            "textarea:not([disabled])",
            "[tabindex]:not([tabindex='-1'])"
        ].join(",");

        const getFocusable = function () {
            return Array.from(element.querySelectorAll(focusableSelectors))
                .filter(function (candidate) {
                    return candidate.offsetParent !== null && !candidate.hasAttribute("disabled");
                });
        };

        if (element.__municipalLibraryTrapFocus) {
            element.focus();
            return;
        }

        element.__municipalLibraryTrapFocus = function (event) {
            if (event.key !== "Tab") {
                return;
            }

            const focusable = getFocusable();
            if (focusable.length === 0) {
                event.preventDefault();
                element.focus();
                return;
            }

            const first = focusable[0];
            const last = focusable[focusable.length - 1];
            const active = document.activeElement;

            if (event.shiftKey && active === first) {
                event.preventDefault();
                last.focus();
            } else if (!event.shiftKey && active === last) {
                event.preventDefault();
                first.focus();
            }
        };

        element.addEventListener("keydown", element.__municipalLibraryTrapFocus);

        const firstFocusable = getFocusable()[0];
        if (firstFocusable) {
            firstFocusable.focus();
        } else {
            element.focus();
        }
    },

    deactivate: function (element) {
        if (!element || !element.__municipalLibraryTrapFocus) {
            return;
        }

        element.removeEventListener("keydown", element.__municipalLibraryTrapFocus);
        delete element.__municipalLibraryTrapFocus;
    }
};
