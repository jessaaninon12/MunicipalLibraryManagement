using MunicipalLibraryManagement.Components.Layout;
using MunicipalLibraryManagement.Tests.Infrastructure;

namespace MunicipalLibraryManagement.Tests.Layout;

public class EmptyLayoutTests : ComponentTestContext
{
    [Fact]
    public void EmptyLayout_SemanticSnapshot_Matches()
    {
        var cut = RenderComponent<EmptyLayout>(parameters => parameters
            .Add(layout => layout.Body, builder => builder.AddMarkupContent(0, "<section id='auth-body'>Auth Body</section>")));

        var snapshot = $$"""
        Layout: EmptyLayout
        ContainsGalaxyShell: {{cut.Markup.Contains("galaxy-shell", StringComparison.Ordinal)}}
        ContainsFluidLayout: {{cut.Markup.Contains("data-testid=\"fluid-layout\"", StringComparison.Ordinal)}}
        ContainsBody: {{cut.Markup.Contains("auth-body", StringComparison.Ordinal)}}
        """;

        SnapshotAssert.Matches(Path.Combine("Layout", "EmptyLayout.semantic.txt"), snapshot);
    }
}
