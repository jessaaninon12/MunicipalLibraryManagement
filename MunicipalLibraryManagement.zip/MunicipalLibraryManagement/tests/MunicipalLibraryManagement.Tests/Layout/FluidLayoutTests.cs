using MunicipalLibraryManagement.Components.Shared;
using MunicipalLibraryManagement.Tests.Infrastructure;

namespace MunicipalLibraryManagement.Tests.Layout;

public class FluidLayoutTests : ComponentTestContext
{
    [Fact]
    public void FluidLayout_SemanticSnapshot_Matches()
    {
        var cut = RenderComponent<FluidLayout>(parameters => parameters
            .AddChildContent("""
                <table class="fluid-responsive-table">
                    <tbody>
                        <tr>
                            <td data-label="Title">Clean Code</td>
                            <td data-label="Stock">4</td>
                        </tr>
                    </tbody>
                </table>
                """));

        var snapshot = $$"""
        Layout: FluidLayout
        RootExists: {{cut.Find("[data-testid='fluid-layout']").ClassName}}
        ContainsResponsiveTable: {{cut.Markup.Contains("fluid-responsive-table", StringComparison.Ordinal)}}
        ContainsBreakpoint1200: {{cut.Markup.Contains("@@media (min-width: 1200px)", StringComparison.Ordinal)}}
        ContainsBreakpoint992: {{cut.Markup.Contains("@@media (min-width: 992px)", StringComparison.Ordinal)}}
        ContainsBreakpoint768: {{cut.Markup.Contains("@@media (min-width: 768px)", StringComparison.Ordinal)}}
        ContainsBreakpoint576: {{cut.Markup.Contains("@@media (min-width: 576px)", StringComparison.Ordinal)}}
        ContainsMobileBreakpoint: {{cut.Markup.Contains("@@media (max-width: 575.98px)", StringComparison.Ordinal)}}
        """;

        SnapshotAssert.Matches(Path.Combine("Layout", "FluidLayout.semantic.txt"), snapshot);
    }
}
