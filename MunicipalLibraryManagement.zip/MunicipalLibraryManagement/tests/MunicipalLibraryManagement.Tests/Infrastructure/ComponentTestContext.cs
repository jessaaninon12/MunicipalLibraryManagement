using Bunit;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.Extensions.DependencyInjection;
using MudBlazor.Services;
using MunicipalLibraryManagement.Data.Enums;
using MunicipalLibraryManagement.Data.Models;
using MunicipalLibraryManagement.Helpers;
using MunicipalLibraryManagement.Services.Interfaces;
using Microsoft.JSInterop;

namespace MunicipalLibraryManagement.Tests.Infrastructure;

public abstract class ComponentTestContext : TestContext
{
    protected ComponentTestContext()
    {
        JSInterop.Mode = JSRuntimeMode.Loose;

        Services.AddMudServices();
        Services.AddScoped<ThemeService>();
        Services.AddScoped<LogoutModalService>();

        var userService = new TestUserService();
        Services.AddSingleton<IUserService>(userService);
        Services.AddSingleton(userService);

        Services.AddScoped<CustomAuthenticationStateProvider>(serviceProvider =>
            new CustomAuthenticationStateProvider(
                serviceProvider.GetRequiredService<IJSRuntime>(),
                serviceProvider.GetRequiredService<IUserService>()));

        Services.AddScoped<AuthenticationStateProvider>(serviceProvider =>
            serviceProvider.GetRequiredService<CustomAuthenticationStateProvider>());
    }

    protected TestUserService UserService => Services.GetRequiredService<TestUserService>();
}

public sealed class TestUserService : IUserService
{
    private readonly List<User> _users =
    [
        new()
        {
            Id = 1,
            Username = "admin",
            PasswordHash = "Admin123!",
            Role = RoleType.Admin
        }
    ];

    private int _nextId = 2;

    public Exception? RegisterException { get; set; }

    public Exception? AuthenticateException { get; set; }

    public Task<User?> AuthenticateAsync(string username, string password)
    {
        if (AuthenticateException is not null)
        {
            throw AuthenticateException;
        }

        var user = _users.FirstOrDefault(existing =>
            string.Equals(existing.Username, username.Trim(), StringComparison.OrdinalIgnoreCase)
            && existing.PasswordHash == password);

        return Task.FromResult(user);
    }

    public Task<User> RegisterAsync(string username, string password) => CreateAsync(username, password, RoleType.Student);

    public Task<User> CreateAsync(string username, string password, RoleType role)
    {
        if (RegisterException is not null)
        {
            throw RegisterException;
        }

        var normalizedUsername = username.Trim();
        if (_users.Any(existing => string.Equals(existing.Username, normalizedUsername, StringComparison.OrdinalIgnoreCase)))
        {
            throw new InvalidOperationException("That username is already in use.");
        }

        if (string.IsNullOrWhiteSpace(password) || password.Length < 8)
        {
            throw new InvalidOperationException("Password must be at least 8 characters long.");
        }

        var user = new User
        {
            Id = _nextId++,
            Username = normalizedUsername,
            PasswordHash = password,
            Role = role,
            CreatedUtc = DateTime.UtcNow
        };

        _users.Add(user);
        return Task.FromResult(user);
    }

    public Task<User> UpdateAsync(int id, string username, string? password, RoleType role)
    {
        var user = _users.First(existing => existing.Id == id);
        user.Username = username.Trim();
        user.Role = role;

        if (!string.IsNullOrWhiteSpace(password))
        {
            user.PasswordHash = password;
        }

        return Task.FromResult(user);
    }

    public Task DeleteAsync(int id)
    {
        _users.RemoveAll(user => user.Id == id);
        return Task.CompletedTask;
    }

    public Task<List<User>> GetAllAsync() => Task.FromResult(_users.OrderBy(user => user.Username).ToList());

    public Task<User?> GetByIdAsync(int id) => Task.FromResult(_users.FirstOrDefault(user => user.Id == id));

    public Task<int> GetUserCountAsync() => Task.FromResult(_users.Count);
}
