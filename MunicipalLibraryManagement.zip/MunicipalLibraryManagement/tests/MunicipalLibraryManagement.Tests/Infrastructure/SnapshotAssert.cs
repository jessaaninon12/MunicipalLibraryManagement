namespace MunicipalLibraryManagement.Tests.Infrastructure;

public static class SnapshotAssert
{
    public static void Matches(string relativePath, string actual)
    {
        var snapshotRoot = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", "Snapshots"));
        var snapshotPath = Path.Combine(snapshotRoot, relativePath);

        Assert.True(File.Exists(snapshotPath), $"Snapshot file was not found: {snapshotPath}");

        var expected = Normalize(File.ReadAllText(snapshotPath));
        Assert.Equal(expected, Normalize(actual));
    }

    private static string Normalize(string value)
    {
        return value.Replace("\r\n", "\n", StringComparison.Ordinal).Trim();
    }
}
