using Bunit;
using MunicipalLibraryManagement.Components.Auth;
using MunicipalLibraryManagement.Tests.Infrastructure;

namespace MunicipalLibraryManagement.Tests.Auth;

public class PasswordFieldTests : ComponentTestContext
{
    [Fact]
    public void PasswordField_Toggles_And_Resets_On_Blur()
    {
        var cut = RenderComponent<PasswordField>(parameters => parameters
            .Add(parameter => parameter.Label, "Password")
            .Add(parameter => parameter.Value, "Guest123!"));

        Assert.Equal("password", cut.Find("input").GetAttribute("type"));

        cut.Find("button[aria-label='Show password']").Click();
        Assert.Equal("text", cut.Find("input").GetAttribute("type"));

        cut.Find(".password-field-shell").TriggerEvent("onfocusout", new FocusEventArgs());
        cut.WaitForAssertion(() => Assert.Equal("password", cut.Find("input").GetAttribute("type")));
    }
}
