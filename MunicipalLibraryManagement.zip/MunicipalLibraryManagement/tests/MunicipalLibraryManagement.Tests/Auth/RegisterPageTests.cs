using Bunit;
using Microsoft.AspNetCore.Components;
using MunicipalLibraryManagement.Components.Pages;
using MunicipalLibraryManagement.Tests.Infrastructure;

namespace MunicipalLibraryManagement.Tests.Auth;

public class RegisterPageTests : ComponentTestContext
{
    [Fact]
    public void RegisterPage_SemanticSnapshot_Matches()
    {
        var cut = RenderComponent<Register>();

        var snapshot = $$"""
        Page: Register
        CardClass: {{cut.Find(".galaxy-auth-card").ClassName}}
        ChipText: {{cut.Find(".mud-chip").TextContent.Trim()}}
        Heading: {{cut.Markup.Contains("Register Guest Account", StringComparison.Ordinal)}}
        PrimaryButton: {{cut.Find("button[type='submit']").TextContent.Trim()}}
        PasswordToggleCount: {{cut.FindAll("button[aria-label='Show password']").Count}}
        BackToLogin: {{cut.Markup.Contains("Back to Login", StringComparison.Ordinal)}}
        """;

        SnapshotAssert.Matches(Path.Combine("Auth", "RegisterPage.semantic.txt"), snapshot);
    }

    [Fact]
    public void Register_Submit_Navigates_To_Login_And_Does_Not_AutoSignIn()
    {
        var cut = RenderComponent<Register>();
        var inputs = cut.FindAll("input");

        inputs[0].Change("newguest");
        inputs[1].Change("Guest1234!");
        inputs[2].Change("Guest1234!");

        cut.Find("form").Submit();

        var navigationManager = Services.GetRequiredService<NavigationManager>();
        Assert.EndsWith("/login?registered=true&username=newguest", navigationManager.Uri, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void Register_ServerValidationError_Shows_Message()
    {
        UserService.RegisterException = new InvalidOperationException("That username is already in use.");

        var cut = RenderComponent<Register>();
        var inputs = cut.FindAll("input");

        inputs[0].Change("admin");
        inputs[1].Change("Admin123!");
        inputs[2].Change("Admin123!");

        cut.Find("form").Submit();

        Assert.Contains("That username is already in use.", cut.Markup, StringComparison.Ordinal);
    }
}
