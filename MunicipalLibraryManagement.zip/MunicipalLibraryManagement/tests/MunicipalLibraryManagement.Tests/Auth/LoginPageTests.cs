using MunicipalLibraryManagement.Components.Pages;
using MunicipalLibraryManagement.Tests.Infrastructure;

namespace MunicipalLibraryManagement.Tests.Auth;

public class LoginPageTests : ComponentTestContext
{
    [Fact]
    public void LoginPage_SemanticSnapshot_Matches()
    {
        var cut = RenderComponent<Login>();

        var snapshot = $$"""
        Page: Login
        CardClass: {{cut.Find(".galaxy-auth-card").ClassName}}
        ChipText: {{cut.Find(".mud-chip").TextContent.Trim()}}
        Heading: {{cut.Markup.Contains("Municipal Library Login", StringComparison.Ordinal)}}
        PrimaryButton: {{cut.Find("button[type='submit']").TextContent.Trim()}}
        PasswordToggleCount: {{cut.FindAll("button[aria-label='Show password']").Count}}
        GuestLink: {{cut.Markup.Contains("Create Guest Account", StringComparison.Ordinal)}}
        """;

        SnapshotAssert.Matches(Path.Combine("Auth", "LoginPage.semantic.txt"), snapshot);
    }
}
