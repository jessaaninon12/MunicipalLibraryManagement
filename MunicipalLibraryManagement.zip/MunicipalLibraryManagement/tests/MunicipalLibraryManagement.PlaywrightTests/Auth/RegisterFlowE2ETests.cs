using Microsoft.Playwright;
using MunicipalLibraryManagement.PlaywrightTests.Infrastructure;

namespace MunicipalLibraryManagement.PlaywrightTests.Auth;

[Collection("playwright")]
public class RegisterFlowE2ETests(PlaywrightAppFixture fixture)
{
    [Fact]
    public async Task Register_Then_Login_Redirects_To_Dashboard()
    {
        var username = $"guest{DateTime.UtcNow:HHmmss}";
        const string password = "Guest1234!";

        await using var context = await fixture.CreateContextAsync(1440, 960);
        var page = await context.NewPageAsync();

        await page.GotoAsync($"{fixture.BaseUrl}/register");

        await page.GetByLabel("Username").FillAsync(username);
        await page.GetByLabel("Password").FillAsync(password);
        await page.GetByLabel("Confirm Password").FillAsync(password);
        await page.GetByRole(AriaRole.Button, new() { Name = "Create Account" }).ClickAsync();

        await page.WaitForURLAsync($"**/login?registered=true&username={username}");
        await Expect(page.GetByText("Account created successfully.")).ToBeVisibleAsync();
        await Expect(page.GetByLabel("Username")).ToHaveValueAsync(username);
        await Expect(page.GetByText("Dashboard")).ToHaveCountAsync(0);

        await page.GetByLabel("Password").FillAsync(password);
        await page.GetByRole(AriaRole.Button, new() { Name = "Login" }).ClickAsync();

        await page.WaitForURLAsync("**/dashboard");
        await Expect(page.GetByText("Dashboard")).ToBeVisibleAsync();
    }
}
