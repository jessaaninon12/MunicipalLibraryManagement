using System.Diagnostics;
using System.Net.Http;
using Microsoft.Playwright;

namespace MunicipalLibraryManagement.PlaywrightTests.Infrastructure;

public sealed class PlaywrightAppFixture : IAsyncLifetime
{
    private Process? _appProcess;
    private IPlaywright? _playwright;
    private IBrowser? _browser;

    public string BaseUrl { get; } = "http://127.0.0.1:5078";

    public async Task InitializeAsync()
    {
        var applicationProject = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", "..", "MunicipalLibraryManagement.csproj"));

        _appProcess = Process.Start(new ProcessStartInfo
        {
            FileName = "dotnet",
            Arguments = $"run --no-build --project \"{applicationProject}\" --urls {BaseUrl}",
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true
        });

        if (_appProcess is null)
        {
            throw new InvalidOperationException("Failed to start the application process for Playwright tests.");
        }

        await WaitForServerAsync();

        _playwright = await Playwright.CreateAsync();
        _browser = await _playwright.Chromium.LaunchAsync(new BrowserTypeLaunchOptions
        {
            Headless = true
        });
    }

    public async Task<IBrowserContext> CreateContextAsync(int width, int height)
    {
        if (_browser is null)
        {
            throw new InvalidOperationException("Browser is not initialized.");
        }

        return await _browser.NewContextAsync(new BrowserNewContextOptions
        {
            BaseURL = BaseUrl,
            IgnoreHTTPSErrors = true,
            ViewportSize = new ViewportSize
            {
                Width = width,
                Height = height
            }
        });
    }

    public async Task DisposeAsync()
    {
        if (_browser is not null)
        {
            await _browser.DisposeAsync();
        }

        _playwright?.Dispose();

        if (_appProcess is not null && !_appProcess.HasExited)
        {
            _appProcess.Kill(entireProcessTree: true);
            await _appProcess.WaitForExitAsync();
        }
    }

    private async Task WaitForServerAsync()
    {
        using var client = new HttpClient();
        var timeoutAt = DateTime.UtcNow.AddSeconds(30);

        while (DateTime.UtcNow < timeoutAt)
        {
            try
            {
                var response = await client.GetAsync($"{BaseUrl}/login");
                if (response.IsSuccessStatusCode)
                {
                    return;
                }
            }
            catch
            {
                // Keep polling until the server responds or the timeout expires.
            }

            await Task.Delay(500);
        }

        throw new TimeoutException("The application did not become ready for Playwright tests within 30 seconds.");
    }
}

[CollectionDefinition("playwright")]
public sealed class PlaywrightCollection : ICollectionFixture<PlaywrightAppFixture>;
