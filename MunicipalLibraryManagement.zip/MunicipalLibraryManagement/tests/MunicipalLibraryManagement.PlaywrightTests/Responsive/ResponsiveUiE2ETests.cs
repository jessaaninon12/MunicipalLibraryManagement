using Microsoft.Playwright;
using MunicipalLibraryManagement.PlaywrightTests.Infrastructure;

namespace MunicipalLibraryManagement.PlaywrightTests.Responsive;

[Collection("playwright")]
public class ResponsiveUiE2ETests(PlaywrightAppFixture fixture)
{
    [Theory]
    [InlineData(1440, 960)]
    [InlineData(1024, 768)]
    [InlineData(390, 844)]
    public async Task Login_And_Register_Critical_Controls_Are_Visible(int width, int height)
    {
        await using var context = await fixture.CreateContextAsync(width, height);
        var page = await context.NewPageAsync();

        await page.GotoAsync($"{fixture.BaseUrl}/login");
        await Expect(page.GetByLabel("Username")).ToBeVisibleAsync();
        await Expect(page.GetByLabel("Password")).ToBeVisibleAsync();
        await Expect(page.GetByRole(AriaRole.Button, new() { Name = "Show password" })).ToBeVisibleAsync();
        await Expect(page.GetByRole(AriaRole.Button, new() { Name = "Login" })).ToBeVisibleAsync();

        await page.GotoAsync($"{fixture.BaseUrl}/register");
        await Expect(page.GetByLabel("Username")).ToBeVisibleAsync();
        await Expect(page.GetByLabel("Password")).ToBeVisibleAsync();
        await Expect(page.GetByLabel("Confirm Password")).ToBeVisibleAsync();
        await Expect(page.GetByRole(AriaRole.Button, new() { Name = "Create Account" })).ToBeVisibleAsync();
    }

    [Theory]
    [InlineData(1440, 960)]
    [InlineData(900, 1100)]
    [InlineData(390, 844)]
    public async Task Logout_Modal_Stays_In_Viewport_And_Closes_With_Escape(int width, int height)
    {
        await using var context = await fixture.CreateContextAsync(width, height);
        var page = await context.NewPageAsync();

        await page.GotoAsync($"{fixture.BaseUrl}/login");
        await page.GetByLabel("Username").FillAsync("guest");
        await page.GetByLabel("Password").FillAsync("Guest123!");
        await page.GetByRole(AriaRole.Button, new() { Name = "Login" }).ClickAsync();
        await page.WaitForURLAsync("**/dashboard");

        if (width < 768)
        {
            await page.GetByRole(AriaRole.Button, new() { Name = "Menu" }).ClickAsync();
        }

        await page.GetByRole(AriaRole.Button, new() { Name = "Logout" }).ClickAsync();

        var dialog = page.GetByRole(AriaRole.Dialog);
        await Expect(dialog).ToBeVisibleAsync();
        await Expect(page.Locator(".floating-modal-backdrop")).ToBeVisibleAsync();

        var box = await dialog.BoundingBoxAsync();
        Assert.NotNull(box);
        Assert.InRange(box!.X, 0, width);
        Assert.InRange(box.Y, 0, height);

        await page.Keyboard.PressAsync("Escape");
        await Expect(dialog).ToHaveCountAsync(0);
    }
}
