using MunicipalLibraryManagement.Data.Models;

namespace MunicipalLibraryManagement.Repositories.Interfaces;

public interface IBorrowRepository
{
    Task<IEnumerable<BorrowTransaction>> GetAllAsync();
    Task<IEnumerable<BorrowTransaction>> GetByUserIdAsync(int userId);
    Task<BorrowTransaction?> GetByIdAsync(int id);
    Task<BorrowTransaction?> GetActiveTransactionByCodeIdAsync(int CodeId);
    Task<BorrowTransaction> AddAsync(BorrowTransaction transaction);
    Task UpdateAsync(BorrowTransaction transaction);
}
