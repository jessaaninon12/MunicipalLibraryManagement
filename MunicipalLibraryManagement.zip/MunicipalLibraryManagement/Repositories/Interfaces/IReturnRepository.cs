using MunicipalLibraryManagement.Data.Models;

namespace MunicipalLibraryManagement.Repositories.Interfaces;

public interface IReturnRepository
{
    Task UpdateTransactionAsync(BorrowTransaction transaction);
}
