using MunicipalLibraryManagement.Data.Models;

namespace MunicipalLibraryManagement.Repositories.Interfaces;

public interface ICodeRepository
{
    Task<IEnumerable<Code>> GetAllByBookIdAsync(int bookId);
    Task<Code?> GetByIdAsync(int id);
    Task<Code?> GetByUniqueCodeAsync(string uniqueCode);
    Task<Code> AddAsync(Code Code);
    Task UpdateAsync(Code Code);
}
