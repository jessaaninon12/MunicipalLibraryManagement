using MunicipalLibraryManagement.Data;
using MunicipalLibraryManagement.Data.Models;
using MunicipalLibraryManagement.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace MunicipalLibraryManagement.Repositories.Implementations;

public class UserRepository(AppDbContext context) : IUserRepository
{
    public async Task<IEnumerable<User>> GetAllAsync() => await context.Users.ToListAsync();

    public async Task<User?> GetByIdAsync(int id) => await context.Users.FindAsync(id);

    public async Task<User?> GetByUsernameAsync(string username) => 
        await context.Users.FirstOrDefaultAsync(u => u.Username == username);

    public async Task<User> AddAsync(User user)
    {
        context.Users.Add(user);
        await context.SaveChangesAsync();
        return user;
    }

    public async Task UpdateAsync(User user)
    {
        context.Entry(user).State = EntityState.Modified;
        await context.SaveChangesAsync();
    }

    public async Task DeleteAsync(int id)
    {
        var user = await context.Users.FindAsync(id);
        if (user != null)
        {
            context.Users.Remove(user);
            await context.SaveChangesAsync();
        }
    }
}
