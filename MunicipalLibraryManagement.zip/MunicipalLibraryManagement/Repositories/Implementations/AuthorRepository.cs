using MunicipalLibraryManagement.Data;
using MunicipalLibraryManagement.Data.Models;
using MunicipalLibraryManagement.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace MunicipalLibraryManagement.Repositories.Implementations;

public class AuthorRepository(AppDbContext context) : IAuthorRepository
{
    public async Task<IEnumerable<Author>> GetAllAsync() => await context.Authors.ToListAsync();

    public async Task<Author?> GetByIdAsync(int id) => await context.Authors.FindAsync(id);

    public async Task<Author> AddAsync(Author author)
    {
        context.Authors.Add(author);
        await context.SaveChangesAsync();
        return author;
    }

    public async Task UpdateAsync(Author author)
    {
        context.Entry(author).State = EntityState.Modified;
        await context.SaveChangesAsync();
    }

    public async Task DeleteAsync(int id)
    {
        var author = await context.Authors.FindAsync(id);
        if (author != null)
        {
            context.Authors.Remove(author);
            await context.SaveChangesAsync();
        }
    }
}
