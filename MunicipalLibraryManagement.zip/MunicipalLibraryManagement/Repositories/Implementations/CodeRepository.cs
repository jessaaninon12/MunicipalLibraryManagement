using MunicipalLibraryManagement.Data;
using MunicipalLibraryManagement.Data.Models;
using MunicipalLibraryManagement.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace MunicipalLibraryManagement.Repositories.Implementations;

public class CodeRepository(AppDbContext context) : ICodeRepository
{
    public async Task<IEnumerable<Code>> GetAllByBookIdAsync(int bookId) => 
        await context.Codes.Where(q => q.BookId == bookId).ToListAsync();

    public async Task<Code?> GetByIdAsync(int id) => await context.Codes.FindAsync(id);

    public async Task<Code?> GetByUniqueCodeAsync(string uniqueCode) => 
        await context.Codes.FirstOrDefaultAsync(q => q.UniqueCode == uniqueCode);

    public async Task<Code> AddAsync(Code Code)
    {
        context.Codes.Add(Code);
        await context.SaveChangesAsync();
        return Code;
    }

    public async Task UpdateAsync(Code Code)
    {
        context.Entry(Code).State = EntityState.Modified;
        await context.SaveChangesAsync();
    }
}
