using MunicipalLibraryManagement.Data;
using MunicipalLibraryManagement.Data.Models;
using MunicipalLibraryManagement.Data.Enums;
using MunicipalLibraryManagement.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace MunicipalLibraryManagement.Repositories.Implementations;

public class BorrowRepository(AppDbContext context) : IBorrowRepository
{
    public async Task<IEnumerable<BorrowTransaction>> GetAllAsync() => 
        await context.BorrowTransactions
            .Include(t => t.User)
            .Include(t => t.Book)
            .Include(t => t.Code)
            .ToListAsync();

    public async Task<IEnumerable<BorrowTransaction>> GetByUserIdAsync(int userId) =>
        await context.BorrowTransactions
            .Include(t => t.Book)
            .Include(t => t.Code)
            .Where(t => t.UserId == userId)
            .ToListAsync();

    public async Task<BorrowTransaction?> GetByIdAsync(int id) => 
        await context.BorrowTransactions
            .Include(t => t.User)
            .Include(t => t.Book)
            .Include(t => t.Code)
            .FirstOrDefaultAsync(t => t.Id == id);

    public async Task<BorrowTransaction?> GetActiveTransactionByCodeIdAsync(int CodeId) => 
        await context.BorrowTransactions
            .FirstOrDefaultAsync(t => t.CodeId == CodeId && t.Status != TransactionStatus.Returned);

    public async Task<BorrowTransaction> AddAsync(BorrowTransaction transaction)
    {
        context.BorrowTransactions.Add(transaction);
        await context.SaveChangesAsync();
        return transaction;
    }

    public async Task UpdateAsync(BorrowTransaction transaction)
    {
        context.Entry(transaction).State = EntityState.Modified;
        await context.SaveChangesAsync();
    }
}
