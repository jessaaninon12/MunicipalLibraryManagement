using MunicipalLibraryManagement.Data;
using MunicipalLibraryManagement.Data.Models;
using MunicipalLibraryManagement.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace MunicipalLibraryManagement.Repositories.Implementations;

public class BookRepository(AppDbContext context) : IBookRepository
{
    public async Task<IEnumerable<Book>> GetAllAsync() => await context.Books.ToListAsync();

    public async Task<Book?> GetByIdAsync(int id) => await context.Books.FindAsync(id);

    public async Task<Book?> GetByIsbnAsync(string isbn) => 
        await context.Books.FirstOrDefaultAsync(b => b.Isbn == isbn);

    public async Task<Book> AddAsync(Book book)
    {
        context.Books.Add(book);
        await context.SaveChangesAsync();
        return book;
    }

    public async Task UpdateAsync(Book book)
    {
        context.Entry(book).State = EntityState.Modified;
        await context.SaveChangesAsync();
    }

    public async Task DeleteAsync(int id)
    {
        var book = await context.Books.FindAsync(id);
        if (book != null)
        {
            context.Books.Remove(book);
            await context.SaveChangesAsync();
        }
    }
}
