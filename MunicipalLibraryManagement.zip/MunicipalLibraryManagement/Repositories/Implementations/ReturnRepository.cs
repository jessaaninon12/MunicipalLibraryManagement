using MunicipalLibraryManagement.Data;
using MunicipalLibraryManagement.Data.Models;
using MunicipalLibraryManagement.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace MunicipalLibraryManagement.Repositories.Implementations;

public class ReturnRepository(AppDbContext context) : IReturnRepository
{
    public async Task UpdateTransactionAsync(BorrowTransaction transaction)
    {
        context.Entry(transaction).State = EntityState.Modified;
        await context.SaveChangesAsync();
    }
}
