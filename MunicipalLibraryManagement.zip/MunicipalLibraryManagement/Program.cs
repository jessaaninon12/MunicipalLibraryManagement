using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.EntityFrameworkCore;
using MudBlazor.Services;
using MunicipalLibraryManagement.Components;
using MunicipalLibraryManagement.Data;
using MunicipalLibraryManagement.Helpers;
using MunicipalLibraryManagement.Repositories.Interfaces;
using MunicipalLibraryManagement.Repositories.Implementations;
using MunicipalLibraryManagement.Services.Interfaces;
using MunicipalLibraryManagement.Services.Implementations;

namespace MunicipalLibraryManagement;

// Configures the application host, dependency injection, and startup initialization.
public class Program
{
    public static async Task Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        builder.Services.AddRazorComponents()
            .AddInteractiveServerComponents();

        builder.Services.AddCascadingAuthenticationState();
        builder.Services.AddAuthorizationCore();
        builder.Services.AddHttpContextAccessor();
        builder.Services.AddMudServices();

        var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
            ?? throw new InvalidOperationException("Connection string 'DefaultConnection' was not found.");
        var configuredServerVersion = builder.Configuration["Database:ServerVersion"] ?? "10.4.32-mariadb";
        var serverVersion = ServerVersion.Parse(configuredServerVersion);

        builder.Services.AddDbContext<AppDbContext>(options =>
            options.UseMySql(connectionString, serverVersion));

        // Existing Helpers
        builder.Services.AddScoped<ThemeService>();
        builder.Services.AddScoped<LogoutModalService>();
        builder.Services.AddScoped<IPasswordHasher, PasswordHasher>();
        builder.Services.AddScoped<DatabaseInitializer>();

        // Repositories
        builder.Services.AddScoped<IUserRepository, UserRepository>();
        builder.Services.AddScoped<IBookRepository, BookRepository>();
        builder.Services.AddScoped<IAuthorRepository, AuthorRepository>();
        builder.Services.AddScoped<IBorrowRepository, BorrowRepository>();
        builder.Services.AddScoped<IReturnRepository, ReturnRepository>();
        builder.Services.AddScoped<ICodeRepository, CodeRepository>();

        // Services
        builder.Services.AddScoped<IUserService, UserService>();
        builder.Services.AddScoped<IBookService, BookService>();
        builder.Services.AddScoped<IAuthorService, AuthorService>();
        builder.Services.AddScoped<IBorrowService, BorrowService>();
        builder.Services.AddScoped<IReturnService, ReturnService>();
        builder.Services.AddScoped<ICodeService, CodeService>();

        // Auth
        builder.Services.AddScoped<CustomAuthenticationStateProvider>();
        builder.Services.AddScoped<AuthenticationStateProvider>(provider => provider.GetRequiredService<CustomAuthenticationStateProvider>());

        var app = builder.Build();

        if (!app.Environment.IsDevelopment())
        {
            app.UseExceptionHandler("/error");
            app.UseHsts();
        }

        app.UseHttpsRedirection();
        app.UseAntiforgery();

        app.MapStaticAssets();
        app.MapRazorComponents<App>()
            .AddInteractiveServerRenderMode();

        using (var scope = app.Services.CreateScope())
        {
            var initializer = scope.ServiceProvider.GetRequiredService<DatabaseInitializer>();
            await initializer.InitializeAsync();
        }

        await app.RunAsync();
    }
}
